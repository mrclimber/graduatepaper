import numpy as np
import matplotlib.pyplot as plt
import random
import cv2
import glob
from tifffile import imwrite

img_rows, img_cols = 200, 200
N = 1024
dt = 0.0005

def imread(filename, flags=cv2.IMREAD_COLOR, dtype=np.uint8):
    try:
        n = np.fromfile(filename, dtype)
        img = cv2.imdecode(n, flags)
        return img
    except Exception as e:
        print(e)
        return None
good_files = glob.glob("/home/masaki/graduatepaper/data/model/new/train_valid/3/clip/good/*")
bad_files = glob.glob("/home/masaki/graduatepaper/data/model/new/train_valid/3/clip/bad/*")
goodlen = len(good_files)
badlen = len(bad_files)

for i in range(1,500,2):

    arr = np.random.rand(1,2)
    arr /= arr.sum(axis=1)[:,np.newaxis]
    # arr *= 2

    x1 = np.random.choice(2,p=[0.5,0.5])
    point1 = 0
    if x1 == 0:
        cond1 = "good"
        point1 = random.randint(0,goodlen-1)
        print("good:",good_files[point1])
        img1 = imread(good_files[point1],0)
    else:
        cond1 = "bad"
        point1 = random.randint(0,badlen-1)
        print("bad:",bad_files[point1])
        img1 = imread(bad_files[point1],0)

    img1 = cv2.resize(img1, (128, 128))

    cond2 = ""
    x2 = np.random.choice(2,p=[0.5,0.5])
    if x2 == 0:
        cond2 = "good"
        point2 = random.randint(0,goodlen-1)
        print("good:",good_files[point2])
        img2 = imread(good_files[point2],0)
    else:
        cond2 = "bad"
        point2 = random.randint(0,badlen-1)
        print("bad:",bad_files[point2])
        img2 = imread(bad_files[point2],0)
    img2 = cv2.resize(img2, (128, 128))


    dft1 = cv2.dft(np.float32(img1),flags=cv2.DFT_COMPLEX_OUTPUT + cv2.DFT_SCALE) * arr[0][0] # type: ignore
    dft_shift1 = np.fft.fftshift(dft1)
    shift1 = np.clip(dft_shift1[:,:,1],0,255).astype(np.uint8)
    magnitude1,angle1 = cv2.cartToPolar(dft_shift1[:,:,0],dft_shift1[:,:,1])

    dft2 = cv2.dft(np.float32(img2),flags=cv2.DFT_COMPLEX_OUTPUT + cv2.DFT_SCALE) * arr[0][1] # type: ignore
    dft_shift2 = np.fft.fftshift(dft2)
    shift2 = np.clip(dft_shift2[:,:,1],0,255).astype(np.uint8)
    magnitude2,angle2 = cv2.cartToPolar(dft_shift2[:,:,0],dft_shift2[:,:,1])

    dft_shift3_real, dft_shift3_imag = cv2.polarToCart(magnitude1, angle2)
    dft_shift3 = np.stack([dft_shift3_real, dft_shift3_imag], axis=-1)
    f_ishift3 = np.fft.ifftshift(dft_shift3)
    img_back3 = cv2.idft(f_ishift3)
    dst3 = np.clip(img_back3[:,:,0],0,255).astype(np.uint8)

    dft_shift4_real, dft_shift4_imag = cv2.polarToCart(magnitude2, angle1)
    dft_shift4 = np.stack([dft_shift4_real, dft_shift4_imag], axis=-1)
    f_ishift4 = np.fft.ifftshift(dft_shift4)
    img_back4 = cv2.idft(f_ishift4)
    dst4 = np.clip(img_back4[:,:,0],0,255).astype(np.uint8)

    if arr[0][0] > arr[0][1]:
        name1 = "/home/masaki/graduatepaper/data/model/new/train_valid/3/train/amppha2/" + cond1 + "/MRIT2画像_AmpPha_" + str(i+500) + '.tif'
        name1_new = "/home/masaki/graduatepaper/data/model/new/train/AmpPha2/2345/all/" + cond1 + "/MRIT2画像_AmpPha_" + str(i+500) + '.tif'
        imwrite(name1,dst3)
        imwrite(name1_new,dst3)
        name2 = "/home/masaki/graduatepaper/data/model/new/train_valid/3/train/amppha2/" + cond2 + "/MRIT2画像_AmpPha_" + str(i+501) + '.tif'
        name2_new = "/home/masaki/graduatepaper/data/model/new/train/AmpPha2/2345/all/" + cond2 + "/MRIT2画像_AmpPha_" + str(i+501) + '.tif'
        imwrite(name2,dst4)
        imwrite(name2_new,dst4)
    else:
        name1 = "/home/masaki/graduatepaper/data/model/new/train_valid/3/train/amppha2/" + cond1 + "/MRIT2画像_AmpPha_" + str(i+500) + '.tif'
        name1_new = "/home/masaki/graduatepaper/data/model/new/train/AmpPha2/2345/all/" + cond1 + "/MRIT2画像_AmpPha_" + str(i+500) + '.tif'
        imwrite(name1,dst3)
        imwrite(name1_new,dst3)
        name2 = "/home/masaki/graduatepaper/data/model/new/train_valid/3/train/amppha2/" + cond2 + "/MRIT2画像_AmpPha_" + str(i+501) + '.tif'
        name2_new = "/home/masaki/graduatepaper/data/model/new/train/AmpPha2/2345/all/" + cond2 + "/MRIT2画像_AmpPha_" + str(i+501) + '.tif'
        imwrite(name2,dst4)
        imwrite(name2_new,dst4)