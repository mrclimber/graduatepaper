import openpyxl
import numpy as np
import cv2
# import matplotlib.pyplot as plt
from tifffile import imwrite
import os
import shutil
import random

book_ehime = openpyxl.load_workbook('E:/graduatepaper/data/OriginalData/Ehime/耳下腺情報シート_愛媛_20210830.xlsx')
ws_ehime = book_ehime.worksheets[0]

book_shizuoka = openpyxl.load_workbook('E:/graduatepaper/data/OriginalData/Shizuoka/耳下腺情報シート_静岡_20210710.xlsx')
ws_shizuoka = book_shizuoka.worksheets[0]

dir_new = ["1234/","1235/","1245/","2345/"]

ehimelist = []
shizuokalist = []
lenehime = []
lenshizuoka = []

for i in range(132):
    k = str(i+2)
    a = 'A' + k
    b = 'B' + k
    t = 'S' + k
    type = str(ws_ehime[t].value)
    a_ehime = str(ws_ehime[a].value)
    b_ehime = str(ws_ehime[b].value)
    i_new_ehime = a_ehime.zfill(3)
    ins = []
    if b_ehime != "None":
        for j in range(5):
            j_new = str(j+1)
            filename_ehime = 'E:/graduatepaper/data/model/new/train_valid/2/validation/all/MRIT2画像_愛媛_' + i_new_ehime + '_' + j_new + '.tif'
            is_file_ehime = os.path.isfile(filename_ehime)
            if is_file_ehime:
                ins.append(i_new_ehime+'_'+j_new)
        if ins != []:
            ehimelist.append(ins)
            lenehime.append(len(ins))


for i in range(132):
    k = str(i+2)
    a = 'A' + k
    b = 'B' + k
    t = 'S' + k
    type = str(ws_shizuoka[t].value)
    a_shizuoka = str(ws_shizuoka[a].value)
    b_shizuoka = str(ws_shizuoka[b].value)
    i_new_shizuoka = a_shizuoka.zfill(3)
    ins = []
    if b_shizuoka != "None":
        for j in range(5):
            j_new = str(j+1)
            filename_shizuoka = 'E:/graduatepaper/data/model/new/train_valid/2/validation/all/MRIT2画像_静岡_' + i_new_shizuoka + '_' + j_new + '.tif'
            is_file_shizuoka = os.path.isfile(filename_shizuoka)
            if is_file_shizuoka:
                i_new_shizuoka = str(int(i_new_shizuoka)+132)
                ins.append(i_new_shizuoka+'_'+j_new)
                i_new_shizuoka = str(int(i_new_shizuoka) - 132).zfill(3)
        if ins != []:
            shizuokalist.append(ins)
            lenshizuoka.append(len(ins))


def imread(filename, flags=cv2.IMREAD_COLOR, dtype=np.uint8):
    try:
        n = np.fromfile(filename, dtype)
        img = cv2.imdecode(n, flags)
        return img
    except Exception as e:
        print(e)
        return None

i = 0
im=""
for length in lenehime:
    x = ehimelist[i]
    x1 = x[0].split('_')
    for count in range(132):
        im = str(count+2)
        fd = 'A' + im
        fd_new = ws_ehime[fd].value
        if fd_new == int(x1[0]):
            t = 'S' + im
            type = str(ws_ehime[t].value)
            break
    a = 'A' + im
    b = 'B' + im
    a_ehime = str(ws_ehime[a].value)
    b_ehime = str(ws_ehime[b].value)
    i_new_ehime = a_ehime.zfill(3)
    # print(x)

    if type == "悪性":
        t_ehime = 1
    else:
        t_ehime = 0

    for j in range(5):
        j_new = str(j+1)
        filename_ehime = 'E:/graduatepaper/data/model/new/train_valid/2/clip/MRIT2画像_愛媛_' + i_new_ehime + '_' + j_new + '.tif'
        is_file_ehime = os.path.isfile(filename_ehime)

        if is_file_ehime:
            img_ehime = imread(filename_ehime,0)
            img_ehime = cv2.resize(img_ehime, (128, 128))

            dft_ehime = cv2.dft(np.float32(img_ehime),flags=cv2.DFT_COMPLEX_OUTPUT + cv2.DFT_SCALE)  # type: ignore
            dft_shift_ehime = np.fft.fftshift(dft_ehime)

            rows, cols = img_ehime.shape
            crow,ccol = rows//2 , cols//2

            mask = np.ones((rows,cols,2),np.uint8)

            mask[crow-10:crow+10, ccol-10:ccol+10] = 0

            fshift_ehime = dft_shift_ehime * mask

            f_ishift_ehime = np.fft.ifftshift(fshift_ehime)
            img_back_ehime = cv2.idft(f_ishift_ehime)
            dst_ehime = np.clip(img_back_ehime[:,:,0],0,255).astype(np.uint8)

            # name_ehime = 'E:/graduatepaper/data/model/new/train_valid/2/train/high/all/MRIT2画像_' + i_new_ehime +'_'+j_new+'.tif'
            # imwrite(name_ehime, dst_ehime)

            if t_ehime == 0:
                name_ehime = 'E:/graduatepaper/data/model/new/train_valid/2/train/high/good/MRIT2画像_愛媛_High_' + i_new_ehime +'_'+j_new+'.tif'
                imwrite(name_ehime, dst_ehime)
                for s in dir_new:
                    name3 = 'E:/graduatepaper/data/model/new/train/HighPass/' + s + 'all/good/MRIT2画像_愛媛_High_' + i_new_ehime + '_' + j_new + '.tif'
                    imwrite(name3,dst_ehime)
                    print(name3)
            else:
                name_ehime = 'E:/graduatepaper/data/model/new/train_valid/2/train/high/bad/MRIT2画像_愛媛_High_' + i_new_ehime +'_'+j_new+'.tif'
                imwrite(name_ehime, dst_ehime)
                for s in dir_new:
                    name3 = 'E:/graduatepaper/data/model/new/train/HighPass/' + s + 'all/bad/MRIT2画像_愛媛_High_' + i_new_ehime + '_' + j_new + '.tif'
                    imwrite(name3,dst_ehime)
            

            for r in range(5):
                r_new = str(r+1)
                dft_ehime = cv2.dft(np.float32(img_ehime),flags=cv2.DFT_COMPLEX_OUTPUT + cv2.DFT_SCALE)  # type: ignore
                dft_shift_ehime = np.fft.fftshift(dft_ehime)

                rows, cols = img_ehime.shape
                crow,ccol = rows//2 , cols//2

                mask = np.ones((rows,cols,2),np.uint8)
                f = random.randint(3,15)
                mask[crow-f:crow+f, ccol-f:ccol+f] = 0

                fshift_ehime = dft_shift_ehime * mask

                f_ishift_ehime = np.fft.ifftshift(fshift_ehime)
                img_back_ehime = cv2.idft(f_ishift_ehime)
                dst_ehime = np.clip(img_back_ehime[:,:,0],0,255).astype(np.uint8)

                # name_ehime = 'E:/graduatepaper/data/model/new/train_valid/2/train/high/all/MRIT2画像_' + i_new_ehime +'_'+j_new+'.tif'
                # imwrite(name_ehime, dst_ehime)

                if t_ehime == 0:
                    name_ehime = 'E:/graduatepaper/data/model/new/train_valid/2/train/high1/good/MRIT2画像_愛媛_High_' + i_new_ehime +'_'+j_new+'_'+r_new+'.tif'
                    imwrite(name_ehime, dst_ehime)
                    for s in dir_new:
                        name3 = 'E:/graduatepaper/data/model/new/train/HighPass1/' + s + 'all/good/MRIT2画像_愛媛_High_' + i_new_ehime + '_' + j_new + '_'+r_new+'.tif'
                        imwrite(name3,dst_ehime)
                        print(name3)
                else:
                    name_ehime = 'E:/graduatepaper/data/model/new/train_valid/2/train/high1/bad/MRIT2画像_愛媛_High_' + i_new_ehime +'_'+j_new+'_'+r_new+'.tif'
                    imwrite(name_ehime, dst_ehime)
                    for s in dir_new:
                        name3 = 'E:/graduatepaper/data/model/new/train/HighPass1/' + s + 'all/bad/MRIT2画像_愛媛_High_' + i_new_ehime + '_' + j_new + '_'+r_new+'.tif'
                        imwrite(name3,dst_ehime)

    i += 1

i = 0
im=""
for length in lenshizuoka:
    x = shizuokalist[i]
    x1 = x[0].split('_')
    ye = int(x1[0])-132
    for count in range(132):
        im = str(count+2)
        fd = 'A' + im
        fd_new = ws_shizuoka[fd].value
        if fd_new == ye:
            t = 'S' + im
            type = str(ws_shizuoka[t].value)
            break
    a = 'A' + im
    b = 'B' + im
    a_shizuoka = str(ws_shizuoka[a].value)
    b_shizuoka = str(ws_shizuoka[b].value)
    i_new_shizuoka = a_shizuoka.zfill(3)

    if type == "悪性":
        t_shizuoka = 1
    else:
        t_shizuoka = 0

    for j in range(5):
        j_new = str(j+1)
        filename_shizuoka = 'E:/graduatepaper/data/model/new/train_valid/2/clip/MRIT2画像_静岡_' + i_new_shizuoka + '_' + j_new + '.tif'
        is_file_shizuoka = os.path.isfile(filename_shizuoka)

        if is_file_shizuoka:
            img_shizuoka = imread(filename_shizuoka,0)
            img_shizuoka = cv2.resize(img_shizuoka, (128, 128))

            dft_shizuoka = cv2.dft(np.float32(img_shizuoka),flags=cv2.DFT_COMPLEX_OUTPUT + cv2.DFT_SCALE)  # type: ignore
            dft_shift_shizuoka = np.fft.fftshift(dft_shizuoka)

            rows, cols = img_shizuoka.shape
            crow,ccol = rows//2 , cols//2

            mask = np.ones((rows,cols,2),np.uint8)

            mask[crow-10:crow+10, ccol-10:ccol+10] = 0

            fshift_shizuoka = dft_shift_shizuoka * mask

            f_ishift_shizuoka = np.fft.ifftshift(fshift_shizuoka)
            img_back_shizuoka = cv2.idft(f_ishift_shizuoka)
            dst_shizuoka = np.clip(img_back_shizuoka[:,:,0],0,255).astype(np.uint8)

            # name_shizuoka = 'E:/graduatepaper/data/model/new/train_valid/2/train/high/all/MRIT2画像_' + i_new_shizuoka +'_'+j_new+'.tif'
            # imwrite(name_shizuoka, dst_shizuoka)

            if t_shizuoka == 0:
                name_shizuoka = 'E:/graduatepaper/data/model/new/train_valid/2/train/high/good/MRIT2画像_静岡_High_' + i_new_shizuoka +'_'+j_new+'.tif'
                imwrite(name_shizuoka, dst_shizuoka)
                for s in dir_new:
                    name3 = 'E:/graduatepaper/data/model/new/train/HighPass/' + s + 'all/good/MRIT2画像_静岡_High_' + i_new_shizuoka + '_' + j_new + '.tif'
                    imwrite(name3,dst_shizuoka)
            else:
                name_shizuoka = 'E:/graduatepaper/data/model/new/train_valid/2/train/high/bad/MRIT2画像_静岡_High_' + i_new_shizuoka +'_'+j_new+'.tif'
                imwrite(name_shizuoka, dst_shizuoka)
                for s in dir_new:
                    name3 = 'E:/graduatepaper/data/model/new/train/HighPass/' + s + 'all/bad/MRIT2画像_静岡_High_' + i_new_shizuoka + '_' + j_new + '.tif'
                    imwrite(name3,dst_shizuoka)

            for r in range(5):
                r_new = str(r+1)
                dft_shizuoka = cv2.dft(np.float32(img_shizuoka),flags=cv2.DFT_COMPLEX_OUTPUT + cv2.DFT_SCALE)  # type: ignore
                dft_shift_shizuoka = np.fft.fftshift(dft_shizuoka)

                rows, cols = img_shizuoka.shape
                crow,ccol = rows//2 , cols//2

                mask = np.ones((rows,cols,2),np.uint8)
                f = random.randint(3,15)
                mask[crow-f:crow+f, ccol-f:ccol+f] = 0

                fshift_shizuoka = dft_shift_shizuoka * mask

                f_ishift_shizuoka = np.fft.ifftshift(fshift_shizuoka)
                img_back_shizuoka = cv2.idft(f_ishift_shizuoka)
                dst_shizuoka = np.clip(img_back_shizuoka[:,:,0],0,255).astype(np.uint8)

                # name_shizuoka = 'E:/graduatepaper/data/model/new/train_valid/2/train/high/all/MRIT2画像_' + i_new_shizuoka +'_'+j_new+'.tif'
                # imwrite(name_shizuoka, dst_shizuoka)

                if t_shizuoka == 0:
                    name_shizuoka = 'E:/graduatepaper/data/model/new/train_valid/2/train/high1/good/MRIT2画像_静岡_High_' + i_new_shizuoka +'_'+j_new+'_'+r_new+'.tif'
                    imwrite(name_shizuoka, dst_shizuoka)
                    for s in dir_new:
                        name3 = 'E:/graduatepaper/data/model/new/train/HighPass1/' + s + 'all/good/MRIT2画像_静岡_High_' + i_new_shizuoka + '_' + j_new +'_'+r_new+ '.tif'
                        imwrite(name3,dst_shizuoka)
                else:
                    name_shizuoka = 'E:/graduatepaper/data/model/new/train_valid/2/train/high1/bad/MRIT2画像_静岡_High_' + i_new_shizuoka +'_'+j_new+'_'+r_new+'.tif'
                    imwrite(name_shizuoka, dst_shizuoka)
                    for s in dir_new:
                        name3 = 'E:/graduatepaper/data/model/new/train/HighPass1/' + s + 'all/bad/MRIT2画像_静岡_High_' + i_new_shizuoka + '_' + j_new + '_'+r_new+'.tif'
                        imwrite(name3,dst_shizuoka)

    i += 1