import numpy as np
import matplotlib.pyplot as plt
import random
import cv2
import glob
from tifffile import imwrite

img_rows, img_cols = 200, 200
N = 1024
dt = 0.0005

def imread(filename, flags=cv2.IMREAD_COLOR, dtype=np.uint8):
    try:
        n = np.fromfile(filename, dtype)
        img = cv2.imdecode(n, flags)
        return img
    except Exception as e:
        print(e)
        return None
good_files = glob.glob("/home/masaki/graduatepaper/data/model/new/train_valid/2/clip/good/*")
bad_files = glob.glob("/home/masaki/graduatepaper/data/model/new/train_valid/2/clip/bad/*")
goodlen = len(good_files)
badlen = len(bad_files)

for i in range(1,2500,2):

    arr = np.random.rand(1,2)
    arr /= arr.sum(axis=1)[:,np.newaxis]
    # arr *= 2

    x1 = np.random.choice(2,p=[0.5,0.5])
    point1 = 0
    if x1 == 0:
        cond1 = "good"
        point1 = random.randint(0,goodlen-1)
        print("good:",good_files[point1])
        img1 = imread(good_files[point1],0)
    else:
        cond1 = "bad"
        point1 = random.randint(0,badlen-1)
        print("bad:",bad_files[point1])
        img1 = imread(bad_files[point1],0)

    img1 = cv2.resize(img1, (128, 128))

    cond2 = ""
    x2 = np.random.choice(2,p=[0.5,0.5])
    if x2 == 0:
        cond2 = "good"
        point2 = random.randint(0,goodlen-1)
        print("good:",good_files[point2])
        img2 = imread(good_files[point2],0)
    else:
        cond2 = "bad"
        point2 = random.randint(0,badlen-1)
        print("bad:",bad_files[point2])
        img2 = imread(bad_files[point2],0)
    img2 = cv2.resize(img2, (128, 128))


    dft1 = cv2.dft(np.float32(img1),flags=cv2.DFT_COMPLEX_OUTPUT + cv2.DFT_SCALE) * arr[0][0] # type: ignore
    dft_shift1 = np.fft.fftshift(dft1)

    dft2 = cv2.dft(np.float32(img2),flags=cv2.DFT_COMPLEX_OUTPUT + cv2.DFT_SCALE) * arr[0][1] # type: ignore
    dft_shift2 = np.fft.fftshift(dft2)

    rows1, cols1 = img1.shape
    crow1,ccol1 = rows1//2 , cols1//2

    mask_low = np.zeros((rows1,cols1,2),np.uint8)

    mask_low[crow1-10:crow1+10, ccol1-10:ccol1+10] = 1

    mask_high = np.ones((rows1,cols1,2),np.uint8)

    mask_high[crow1-10:crow1+10, ccol1-10:ccol1+10] = 0

    fshift1_low = dft_shift1*mask_low

    fshift1_high = dft_shift1*mask_high

    fshift2_low = dft_shift2*mask_low

    fshift2_high = dft_shift2*mask_high

    fshift1 = fshift1_low + fshift2_high

    fshift2 = fshift1_high + fshift2_low

    f_ishift1 = np.fft.ifftshift(fshift1)
    img_back1 = cv2.idft(f_ishift1)
    dst1 = np.clip(img_back1[:,:,0],0,255).astype(np.uint8)

    f_ishift2 = np.fft.ifftshift(fshift2)
    img_back2 = cv2.idft(f_ishift2)
    dst2 = np.clip(img_back2[:,:,0],0,255).astype(np.uint8)

    if arr[0][0] > arr[0][1]:
        name1 = "/home/masaki/graduatepaper/data/model/new/train_valid/2/train/highlow3/" + cond1 + "/MRIT2画像_HighLow_" + str(i) + '.tif'
        name1_new = "/home/masaki/graduatepaper/data/model/new/train/HighLow3/2345/all/" + cond1 + "/MRIT2画像_HighLow_" + str(i) + '.tif'
        imwrite(name1,dst1)
        imwrite(name1_new,dst1)
        name2 = "/home/masaki/graduatepaper/data/model/new/train_valid/2/train/highlow3/" + cond2 + "/MRIT2画像_HighLow_" + str(i+1) + '.tif'
        name2_new = "/home/masaki/graduatepaper/data/model/new/train/HighLow3/2345/all/" + cond2 + "/MRIT2画像_HighLow_" + str(i+1) + '.tif'
        imwrite(name2,dst2)
        imwrite(name2_new,dst2)
    else:
        name1 = "/home/masaki/graduatepaper/data/model/new/train_valid/2/train/highlow3/" + cond1 + "/MRIT2画像_HighLow_" + str(i) + '.tif'
        name1_new = "/home/masaki/graduatepaper/data/model/new/train/HighLow3/2345/all/" + cond1 + "/MRIT2画像_HighLow_" + str(i) + '.tif'
        imwrite(name1,dst1)
        imwrite(name1_new,dst1)
        name2 = "/home/masaki/graduatepaper/data/model/new/train_valid/2/train/highlow3/" + cond2 + "/MRIT2画像_HighLow_" + str(i+1) + '.tif'
        name2_new = "/home/masaki/graduatepaper/data/model/new/train/HighLow3/2345/all/" + cond2 + "/MRIT2画像_HighLow_" + str(i+1) + '.tif'
        imwrite(name2,dst2)
        imwrite(name2_new,dst2)

