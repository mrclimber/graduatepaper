import openpyxl
import numpy as np
import cv2
from tifffile import imwrite
import os
import random
import shutil
from skimage import io

# # ブックを取得
book_ehime = openpyxl.load_workbook('E:/graduatepaper/data/耳下腺情報シート_愛媛_20210830.xlsx')
book_shizuoka = openpyxl.load_workbook('E:/graduatepaper/data/耳下腺情報シート_静岡_20210710.xlsx')

ws_ehime = book_ehime.worksheets[0]
ws_shizuoka = book_shizuoka.worksheets[0]


ehimelist = []
shizuokalist = []
lenehime = []
lenshizuoka = []

for i in range(132):
    k = str(i+2)
    a = 'A' + k
    b = 'B' + k
    t = 'S' + k
    type = str(ws_ehime[t].value)
    a_ehime = str(ws_ehime[a].value)
    b_ehime = str(ws_ehime[b].value)
    i_new_ehime = a_ehime.zfill(3)
    ins = []
    if b_ehime != "None":
        for j in range(5):
            j_new = str(j+1)
            filename_ehime = 'E:/graduatepaper/data/model/new/train_valid/2/validation/all/MRIT2画像_愛媛_' + i_new_ehime + '_' + j_new + '.tif'
            is_file_ehime = os.path.isfile(filename_ehime)
            if is_file_ehime:
                ins.append(i_new_ehime+'_'+j_new)
        if ins != []:
            ehimelist.append(ins)
            lenehime.append(len(ins))

for i in range(132):
    k = str(i+2)
    a = 'A' + k
    b = 'B' + k
    t = 'S' + k
    type = str(ws_shizuoka[t].value)
    a_shizuoka = str(ws_shizuoka[a].value)
    b_shizuoka = str(ws_shizuoka[b].value)
    i_new_shizuoka = a_shizuoka.zfill(3)
    ins = []
    if b_shizuoka != "None":
        for j in range(5):
            j_new = str(j+1)
            filename_shizuoka = 'E:/graduatepaper/data/model/new/train_valid/2/validation/all/MRIT2画像_静岡_' + i_new_shizuoka + '_' + j_new + '.tif'
            is_file_shizuoka = os.path.isfile(filename_shizuoka)
            if is_file_shizuoka:
                i_new_shizuoka = str(int(i_new_shizuoka)+132)
                ins.append(i_new_shizuoka+'_'+j_new)
                i_new_shizuoka = str(int(i_new_shizuoka) - 132).zfill(3)
        if ins != []:
            shizuokalist.append(ins)
            lenshizuoka.append(len(ins))
i = 0
im=""
j_flag = 0
w = 0
x = 0
y = 0
z = 0
for length in lenehime:
    x = ehimelist[i]
    x1 = x[0].split('_')
    for count in range(132):
        im = str(count+2)
        fd = 'A' + im
        fd_new = ws_ehime[fd].value
        if fd_new == int(x1[0]):
            t = 'S' + im
            type = str(ws_ehime[t].value)
            break
    a = 'A' + im
    b = 'B' + im
    a_ehime = str(ws_ehime[a].value)
    b_ehime = str(ws_ehime[b].value)
    i_new_ehime = a_ehime.zfill(3)

    for j in range(5):
        path = "E:/graduatepaper/data/model/new/train_valid/2/datalist/" # パスを格納
        j_new = str(j+1)
        name = 'MRIT2画像_愛媛_'+i_new_ehime+'_'+j_new+'.tif'
        name = path+name
        is_file = os.path.isfile(name)
        if is_file:
            img = io.imread(name) # これでOK
            n = lenehime[i]
            # print(n)
            if n == 1:
                if j == 0 or j == 1 or j == 2 or j == 3 or j == 4:
                    j_flag = 1
            if n == 2:
                if j == 0 or j == 2 or j == 3:
                    j_flag = 1
                if j == 1 or j == 4:
                    j_flag = 2
            if n == 3:
                if j == 0 or j == 3:
                    j_flag = 1
                if j == 1 or j == 4:
                    j_flag = 2
                if j == 2:
                    j_flag = j + 1
            if n == 4:
                if j == 0 or j == 4:
                    j_flag = 1
                else:
                    j_flag = j + 1
            if n == 5:
                j_flag = j + 1


            if j_flag == 1:
                w = 'W'+im
                x = 'X'+im
                y = 'Y'+im
                z = 'Z'+im
            if j_flag == 2:
                w = 'AA'+im
                x = 'AB'+im
                y = 'AC'+im
                z = 'AD'+im
            if j_flag == 3:
                w = 'AE'+im
                x = 'AF'+im
                y = 'AG'+im
                z = 'AH'+im
            if j_flag == 4:
                w = 'AI'+im
                x = 'AJ'+im
                y = 'AK'+im
                z = 'AL'+im
            if j_flag == 5:
                w = 'AM'+im
                x = 'AN'+im
                y = 'AO'+im
                z = 'AP'+im

            w = ws_ehime[w].value
            x = ws_ehime[x].value
            y = ws_ehime[y].value
            z = ws_ehime[z].value
            gamma = random.uniform(1.1,1.4)
            LUT_Table=np.zeros((256,1),dtype='uint8')
            for lut in range(len(LUT_Table)):
                LUT_Table[lut][0]=255*(float(lut)/255)**(1.0/gamma)
            img_bright = cv2.LUT(img,LUT_Table)
            name_bright = 'E:/graduatepaper/data/model/new/train_valid/2/train/bright/MRIT2画像_愛媛_bright_' + i_new_ehime + '_' + j_new + '.tif'
            imwrite(name_bright, img_bright)
            LUT_Table=np.zeros((256,1),dtype='uint8')
            gamma = random.uniform(0.75,0.9)
            for lut in range(len(LUT_Table)):
                LUT_Table[lut][0]=255*(float(lut)/255)**(1.0/gamma)
            img_dark = cv2.LUT(img,LUT_Table)
            name_dark = 'E:/graduatepaper/data/model/new/train_valid/2/train/dark/MRIT2画像_愛媛_dark_' + i_new_ehime + '_' + j_new + '.tif'
            imwrite(name_dark, img_dark)
            for r in range(5):
                r_new = str(r+1)
                gamma = random.uniform(1.1,1.4)
                LUT_Table=np.zeros((256,1),dtype='uint8')
                for lut in range(len(LUT_Table)):
                    LUT_Table[lut][0]=255*(float(lut)/255)**(1.0/gamma)
                img_bright = cv2.LUT(img,LUT_Table)
                img_bright = img_bright[x:x+z,w:w+y]
                name_bright = 'E:/graduatepaper/data/model/new/train_valid/2/train/bright1/MRIT2画像_愛媛_bright_' + i_new_ehime + '_' + j_new + '_' + r_new + '.tif'
                imwrite(name_bright, img_bright)
                LUT_Table=np.zeros((256,1),dtype='uint8')
                gamma = random.uniform(0.75,0.9)
                for lut in range(len(LUT_Table)):
                    LUT_Table[lut][0]=255*(float(lut)/255)**(1.0/gamma)
                img_dark = cv2.LUT(img,LUT_Table)
                img_dark = img_dark[x:x+z,w:w+y]
                name_dark = 'E:/graduatepaper/data/model/new/train_valid/2/train/dark1/MRIT2画像_愛媛_dark_' + i_new_ehime + '_' + j_new + '_' + r_new + '.tif'
                imwrite(name_dark, img_dark)

    i += 1
i = 0
for length in lenshizuoka:
    x = shizuokalist[i]
    x1 = x[0].split('_')
    ye = int(x1[0])-132
    for count in range(132):
        im = str(count+2)
        fd = 'A' + im
        fd_new = ws_shizuoka[fd].value
        if fd_new == ye:
            t = 'S' + im
            type = str(ws_shizuoka[t].value)
            break
    a = 'A' + im
    b = 'B' + im
    a_shizuoka = str(ws_shizuoka[a].value)
    b_shizuoka = str(ws_shizuoka[b].value)
    i_new_shizuoka = a_shizuoka.zfill(3)
    for j in range(5):
        path = "E:/graduatepaper/data/model/new/train_valid/2/datalist/" # パスを格納
        j_new = str(j+1)
        name = 'MRIT2画像_静岡_'+i_new_shizuoka+'_'+j_new+'.tif'
        name = path+name
        is_file = os.path.isfile(name)
        if is_file:
            n = lenshizuoka[i]
            # print(n)
            if n == 1:
                if j == 0 or j == 1 or j == 2 or j == 3 or j == 4:
                    j_flag = 1
            if n == 2:
                if j == 0 or j == 2 or j == 3:
                    j_flag = 1
                if j == 1 or j == 4:
                    j_flag = 2
            if n == 3:
                if j == 0 or j == 3:
                    j_flag = 1
                if j == 1 or j == 4:
                    j_flag = 2
                if j == 2:
                    j_flag = j + 1
            if n == 4:
                if j == 0 or j == 4:
                    j_flag = 1
                else:
                    j_flag = j + 1
            if n == 5:
                j_flag = j + 1

            if j_flag == 1:
                w = 'U'+im
                x = 'V'+im
                y = 'W'+im
                z = 'X'+im
            if j_flag == 2:
                w = 'Y'+im
                x = 'Z'+im
                y = 'AA'+im
                z = 'AB'+im
            if j_flag == 3:
                w = 'AC'+im
                x = 'AD'+im
                y = 'AE'+im
                z = 'AF'+im
            if j_flag == 4:
                w = 'AG'+im
                x = 'AH'+im
                y = 'AI'+im
                z = 'AJ'+im
            if j_flag == 5:
                w = 'AK'+im
                x = 'AL'+im
                y = 'AM'+im
                z = 'AN'+im
            
            w = ws_shizuoka[w].value
            x = ws_shizuoka[x].value
            y = ws_shizuoka[y].value
            z = ws_shizuoka[z].value

            img = io.imread(name) # これでOK
            LUT_Table=np.zeros((256,1),dtype='uint8')
            gamma = random.uniform(1.1,1.4)
            for lut in range(len(LUT_Table)):
                LUT_Table[lut][0]=255*(float(lut)/255)**(1.0/gamma)
            img_bright = cv2.LUT(img,LUT_Table)
            name_bright = 'E:/graduatepaper/data/model/new/train_valid/2/train/bright/MRIT2画像_静岡_bright_' + i_new_shizuoka + '_' + j_new + '.tif'
            imwrite(name_bright, img_bright)
            LUT_Table=np.zeros((256,1),dtype='uint8')
            for lut in range(len(LUT_Table)):
                LUT_Table[lut][0]=255*(float(lut)/255)**(1.0/gamma)
            img_dark = cv2.LUT(img,LUT_Table)
            name_dark = 'E:/graduatepaper/data/model/new/train_valid/2/train/dark/MRIT2画像_静岡_dark_' + i_new_shizuoka + '_' + j_new + '.tif'
            imwrite(name_dark, img_dark)
            for r in range(5):
                r_new = str(r+1)
                LUT_Table=np.zeros((256,1),dtype='uint8')
                gamma = random.uniform(1.1,1.4)
                for lut in range(len(LUT_Table)):
                    LUT_Table[lut][0]=255*(float(lut)/255)**(1.0/gamma)
                img_bright = cv2.LUT(img,LUT_Table)
                img_bright = img_bright[x:x+z,w:w+y]
                name_bright = 'E:/graduatepaper/data/model/new/train_valid/2/train/bright1/MRIT2画像_静岡_bright_' + i_new_shizuoka + '_' + j_new + '_' + r_new + '.tif'
                imwrite(name_bright, img_bright)
                LUT_Table=np.zeros((256,1),dtype='uint8')
                for lut in range(len(LUT_Table)):
                    LUT_Table[lut][0]=255*(float(lut)/255)**(1.0/gamma)
                img_dark = cv2.LUT(img,LUT_Table)
                img_dark = img_dark[x:x+z,w:w+y]
                name_dark = 'E:/graduatepaper/data/model/new/train_valid/2/train/dark1/MRIT2画像_静岡_dark_' + i_new_shizuoka + '_' + j_new + '_' + r_new + '.tif'
                imwrite(name_dark, img_dark)

    i += 1

