import openpyxl
import numpy as np
import cv2
from tifffile import imwrite
import os
import random
import shutil
from skimage import io

# # ブックを取得
book_ehime = openpyxl.load_workbook('/home/masaki/graduatepaper/data/耳下腺情報シート_愛媛_20210830.xlsx')
book_shizuoka = openpyxl.load_workbook('/home/masaki/graduatepaper/data/耳下腺情報シート_静岡_20210710.xlsx')

ws_ehime = book_ehime.worksheets[0]
ws_shizuoka = book_shizuoka.worksheets[0]

dir_new = ["1234/","1245/","1345/","2345/"]

ehimelist = []
shizuokalist = []
lenehime = []
lenshizuoka = []
alllist = []
for i in range(132):
    k = str(i+2)
    a = 'A' + k
    b = 'B' + k
    t = 'S' + k
    type = str(ws_ehime[t].value)
    a_ehime = str(ws_ehime[a].value)
    b_ehime = str(ws_ehime[b].value)
    i_new_ehime = a_ehime.zfill(3)
    ins = []
    if b_ehime != "None":
        for j in range(5):
            j_new = str(j+1)
            filename_ehime = '/home/masaki/graduatepaper/data/model/new/train_valid/4/clip/good/MRIT2画像_愛媛_' + i_new_ehime + '_' + j_new + '.tif'
            is_file_ehime = os.path.isfile(filename_ehime)
            if is_file_ehime:
                ins.append(i_new_ehime+'_'+j_new)
        if ins != []:
            ehimelist.append(ins)
            alllist.append(ins)
            lenehime.append(len(ins))

for i in range(132):
    k = str(i+2)
    a = 'A' + k
    b = 'B' + k
    t = 'S' + k
    type = str(ws_shizuoka[t].value)
    a_shizuoka = str(ws_shizuoka[a].value)
    b_shizuoka = str(ws_shizuoka[b].value)
    i_new_shizuoka = a_shizuoka.zfill(3)
    ins = []
    if b_shizuoka != "None":
        for j in range(5):
            j_new = str(j+1)
            filename_shizuoka = '/home/masaki/graduatepaper/data/model/new/train_valid/4/clip/good/MRIT2画像_静岡_' + i_new_shizuoka + '_' + j_new + '.tif'
            is_file_shizuoka = os.path.isfile(filename_shizuoka)
            if is_file_shizuoka:
                i_new_shizuoka = str(int(i_new_shizuoka)+132)
                ins.append(i_new_shizuoka+'_'+j_new)
                i_new_shizuoka = str(int(i_new_shizuoka) - 132).zfill(3)
        if ins != []:
            shizuokalist.append(ins)
            alllist.append(ins)
            lenshizuoka.append(len(ins))


def imread(filename, flags=cv2.IMREAD_COLOR, dtype=np.uint8):
    try:
        n = np.fromfile(filename, dtype)
        img = cv2.imdecode(n, flags)
        return img
    except Exception as e:
        print(e)
        return None


for i in range(1,len(alllist)*100,2):
    t1 = random.choice(random.choice(alllist)).split('_')
    t2 = random.choice(random.choice(alllist)).split('_')
    if t1[0] == "132":
        div1 = 0
    else:
        div1 = int(int(t1[0]) / 132)
    if t2[0] == "132":
        div2 = 0
    else:
        div2 = int(int(t2[0]) / 132)
    if t1[0] == "132":
        num1 = 132
    else:
        num1 = int(t1[0]) % 132
    if t2[0] == "132":
        num2 = 132
    else:
        num2 = int(t2[0]) % 132
    num1 = str(num1)
    num2 = str(num2)
    num1_new = num1.zfill(3)
    num2_new = num2.zfill(3)   
    t = 'S' + str(i+2)
    if div1:
        name1 = "静岡"
    else:
        name1 = '愛媛'
    if div2:
        name2 = '静岡'
    else:
        name2 = '愛媛'
    
    j1_new = str(t1[1])
    j2_new = str(t2[1])

    filename1 = '/home/masaki/graduatepaper/data/model/new/train_valid/4/clip/good/MRIT2画像_' + name1 + '_' + num1_new + '_' + j1_new + '.tif'
    filename2 = '/home/masaki/graduatepaper/data/model/new/train_valid/4/clip/good/MRIT2画像_' + name2 + '_' + num2_new + '_' + j2_new + '.tif'
    is_file1 = os.path.isfile(filename1)
    is_file2 = os.path.isfile(filename2)
    img1 = imread(filename1,0)
    img1 = cv2.resize(img1, (128, 128))

    img2 = imread(filename2,0)
    img2 = cv2.resize(img2, (128, 128))
    
    # print("filename1:",filename1)
    # print("filename2:",filename2)
    
    dft1 = cv2.dft(np.float32(img1),flags=cv2.DFT_COMPLEX_OUTPUT + cv2.DFT_SCALE)  # type: ignore
    dft_shift1 = np.fft.fftshift(dft1)
    shift1 = np.clip(dft_shift1[:,:,1],0,255).astype(np.uint8)
    magnitude1,angle1 = cv2.cartToPolar(dft_shift1[:,:,0],dft_shift1[:,:,1])

    dft2 = cv2.dft(np.float32(img2),flags=cv2.DFT_COMPLEX_OUTPUT + cv2.DFT_SCALE)  # type: ignore
    dft_shift2 = np.fft.fftshift(dft2)
    shift2 = np.clip(dft_shift2[:,:,1],0,255).astype(np.uint8)
    magnitude2,angle2 = cv2.cartToPolar(dft_shift2[:,:,0],dft_shift2[:,:,1])

    dft_shift3_real, dft_shift3_imag = cv2.polarToCart(magnitude1, angle2)
    dft_shift3 = np.stack([dft_shift3_real, dft_shift3_imag], axis=-1)
    f_ishift3 = np.fft.ifftshift(dft_shift3)
    img_back3 = cv2.idft(f_ishift3)
    dst3 = np.clip(img_back3[:,:,0],0,255).astype(np.uint8)

    dft_shift4_real, dft_shift4_imag = cv2.polarToCart(magnitude2, angle1)
    dft_shift4 = np.stack([dft_shift4_real, dft_shift4_imag], axis=-1)
    f_ishift4 = np.fft.ifftshift(dft_shift4)
    img_back4 = cv2.idft(f_ishift4)
    dst4 = np.clip(img_back4[:,:,0],0,255).astype(np.uint8)

    name3 = '/home/masaki/graduatepaper/data/model/new/train_valid/4/train/amppha1/good/MRIT2画像_AmpPha_' + str(i) + '.tif'
    imwrite(name3, dst3)
    name4 = '/home/masaki/graduatepaper/data/model/new/train_valid/4/train/amppha1/good/MRIT2画像_AmpPha_' + str(i+1) + '.tif'
    imwrite(name4, dst4)

    for s in dir_new:
        name3 = '/home/masaki/graduatepaper/data/model/new/train/AmpPha1/' + s + 'all/good/MRIT2画像_AmpPha_' + str(i) + '.tif'
        imwrite(name3,dst3)
        name4 = '/home/masaki/graduatepaper/data/model/new/train/AmpPha1/' + s + 'all/good/MRIT2画像_AmpPha_' + str(i+1) + '.tif'
        imwrite(name4,dst4)