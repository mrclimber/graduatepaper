from multiprocessing.connection import wait
from re import X
from tifffile import TiffFile
import numpy as np
import cv2
from skimage import io
import matplotlib.pyplot as plt
from tifffile import imwrite
import os
from PIL import Image
import openpyxl

book_ehime = openpyxl.load_workbook('/home/masaki/graduatepaper/data/耳下腺情報シート_愛媛_20210830.xlsx')
book_shizuoka = openpyxl.load_workbook('/home/masaki/graduatepaper/data/耳下腺情報シート_静岡_20210710.xlsx')

ws_ehime = book_ehime.worksheets[0]
ws_shizuoka = book_shizuoka.worksheets[0]

ehimelist = []
shizuokalist = []
alllist = []
lenehime = []
lenshizuoka = []  

for i in range(132):
    k = str(i+2)
    a = 'A' + k
    b = 'B' + k
    t = 'S' + k
    type = str(ws_ehime[t].value)
    a_ehime = str(ws_ehime[a].value)
    b_ehime = str(ws_ehime[b].value)
    i_new_ehime = a_ehime.zfill(3)
    ins = []
    if b_ehime != "None":
        for j in range(5):
            j_new = str(j+1)
            filename_ehime = '/home/masaki/graduatepaper/data/model/new/train_valid/5/validation/all/MRIT2画像_愛媛_' + i_new_ehime + '_' + j_new + '.tif'
            is_file_ehime = os.path.isfile(filename_ehime)
            if is_file_ehime:
                ins.append(i_new_ehime+'_'+j_new)
        if ins != []:
            alllist.append(ins)
            ehimelist.append(ins)
            lenehime.append(len(ins))

for i in range(132):
    k = str(i+2)
    a = 'A' + k
    b = 'B' + k
    t = 'S' + k
    type = str(ws_shizuoka[t].value)
    a_shizuoka = str(ws_shizuoka[a].value)
    b_shizuoka = str(ws_shizuoka[b].value)
    i_new_shizuoka = a_shizuoka.zfill(3)
    ins = []
    if b_shizuoka != "None":
        for j in range(5):
            j_new = str(j+1)
            filename_shizuoka = '/home/masaki/graduatepaper/data/model/new/train_valid/5/validation/all/MRIT2画像_静岡_' + i_new_shizuoka + '_' + j_new + '.tif'
            is_file_shizuoka = os.path.isfile(filename_shizuoka)
            if is_file_shizuoka:
                i_new_shizuoka = str(int(i_new_shizuoka)+132)
                ins.append(i_new_shizuoka+'_'+j_new)
                i_new_shizuoka = str(int(i_new_shizuoka) - 132).zfill(3)
        if ins != []:
            alllist.append(ins)
            shizuokalist.append(ins)
            lenshizuoka.append(len(ins))

base = "/home/masaki/graduatepaper/data/" # パスを格納
base_old = base + "model/new/train_valid/5/train/"
base_new = base + "model/new/train/"
base_train = base + "model/train/base/"
bright = "bright/"
dark = "dark/"
ave = "ave/"
bilat = "bilat/"
gaus = "gaussian/"
median = "median/"
noise = "noise/"
xshear = "xshear/"
y_shear = "yshear/"
shift = "shift/"
round = "round/"
dir_new = ["2345/all/"]#"1235/all/","1245/all/","1345/all/",
trainlist = ["base/","AmpPha/","AmpPha2/","HighPass/","LowPass/","HighLow/","HighLow2/"]

j_flag = 0
w = None
x = None
y = None
z = None

im=""
type=""
for i in range(len(lenehime)):
    x = ehimelist[i]
    x1 = x[0].split('_')
    for count in range(132):
        im = str(count+2)
        fd = 'A' + im
        fd_new = ws_ehime[fd].value
        if fd_new == int(x1[0]):
            t = 'S' + im
            type = str(ws_ehime[t].value)
            break
    a = 'A' + im
    b = 'B' + im
    a_ehime = str(ws_ehime[a].value)
    b_ehime = str(ws_ehime[b].value)
    i_new_ehime = a_ehime.zfill(3)

    for j in range(5):
        j_new = str(j+1)
        if type == "良性":
            condition_ehime = "good/"
        else:
            condition_ehime = "bad/"


        
        bright_ehime = base_old + bright +  'MRIT2画像_愛媛_bright_'+i_new_ehime+'_'+j_new+'.tif'
        dark_ehime = base_old + dark + 'MRIT2画像_愛媛_dark_'+i_new_ehime+'_'+j_new+'.tif'
        ave_ehime = base_old + ave +  'MRIT2画像_愛媛_ave_'+i_new_ehime+'_'+j_new+'.tif'
        bilat_ehime = base_old + bilat + 'MRIT2画像_愛媛_bilat_'+i_new_ehime+'_'+j_new+'.tif'
        gaus_ehime = base_old + gaus + 'MRIT2画像_愛媛_gaussian_'+i_new_ehime+'_'+j_new+'.tif'
        median_ehime = base_old + median + 'MRIT2画像_愛媛_median_'+i_new_ehime+'_'+j_new+'.tif'
        noise_ehime = base_old + noise + 'MRIT2画像_愛媛_noise_'+i_new_ehime+'_'+j_new+'.tif'
        xshear_ehime = base_old + xshear +  'MRIT2画像_愛媛_xshear_'+i_new_ehime+'_'+j_new+'.tif'
        yshear_ehime = base_old + y_shear + 'MRIT2画像_愛媛_yshear_'+i_new_ehime+'_'+j_new+'.tif'
        shift_ehime = base_old + shift + 'MRIT2画像_愛媛_shift_'+i_new_ehime+'_'+j_new+'.tif'
        round_ehime = base_old + round  + 'MRIT2画像_愛媛_round_' + i_new_ehime + '_' + j_new + '.tif'
        
        is_file_ehime = os.path.isfile(bright_ehime)
        if is_file_ehime:
            n = lenehime[i]
            # print(n)
            if n == 1:
                if j == 0 or j == 1 or j == 2 or j == 3 or j == 4:
                    j_flag = 1
            if n == 2:
                if j == 0 or j == 2 or j == 3:
                    j_flag = 1
                if j == 1 or j == 4:
                    j_flag = 2
            if n == 3:
                if j == 0 or j == 3:
                    j_flag = 1
                if j == 1 or j == 4:
                    j_flag = 2
                if j == 2:
                    j_flag = j + 1
            if n == 4:
                if j == 0 or j == 4:
                    j_flag = 1
                else:
                    j_flag = j + 1
            if n == 5:
                j_flag = j + 1


            if j_flag == 1:
                w = 'W'+im
                x = 'X'+im
                y = 'Y'+im
                z = 'Z'+im
            if j_flag == 2:
                w = 'AA'+im
                x = 'AB'+im
                y = 'AC'+im
                z = 'AD'+im
            if j_flag == 3:
                w = 'AE'+im
                x = 'AF'+im
                y = 'AG'+im
                z = 'AH'+im
            if j_flag == 4:
                w = 'AI'+im
                x = 'AJ'+im
                y = 'AK'+im
                z = 'AL'+im
            if j_flag == 5:
                w = 'AM'+im
                x = 'AN'+im
                y = 'AO'+im
                z = 'AP'+im

            w = ws_ehime[w].value
            x = ws_ehime[x].value
            y = ws_ehime[y].value
            z = ws_ehime[z].value

            img_bright = io.imread(bright_ehime)
            img_dark = io.imread(dark_ehime)
            img_ave = io.imread(ave_ehime)
            img_bilat = io.imread(bilat_ehime)
            img_gaus = io.imread(gaus_ehime)
            img_median = io.imread(median_ehime)
            img_noise = io.imread(noise_ehime)
            img_xshear = io.imread(xshear_ehime)
            img_yshear = io.imread(yshear_ehime)
            img_shift = io.imread(shift_ehime)
            img_round = io.imread(round_ehime)

            # img_bright = img_bright[x:x+z,w:w+y]
            # img_dark = img_dark[x:x+z,w:w+y]
            # img_ave = img_ave[x:x+z,w:w+y]
            # img_bilat = img_bilat[x:x+z,w:w+y]
            # img_gaus = img_gaus[x:x+z,w:w+y]
            # img_median = img_median[x:x+z,w:w+y]
            # img_noise = img_noise[x:x+z,w:w+y]
            # img_xshear = img_xshear[x:x+z,w:w+y]
            # img_yshear = img_yshear[x:x+z,w:w+y]
            # img_shift = img_shift[x:x+z,w:w+y]
            # img_round = img_round[x:x+z,w:w+y]

            for q in trainlist:
                for r in dir_new:
                    bright_ehime = base_new + q + r + condition_ehime + 'MRIT2画像_愛媛_bright_'+i_new_ehime+'_'+j_new+'.tif'
                    print(bright_ehime)
                    dark_ehime = base_new + q + r +  condition_ehime + 'MRIT2画像_愛媛_dark_'+i_new_ehime+'_'+j_new+'.tif'
                    ave_ehime = base_new + q + r + condition_ehime + 'MRIT2画像_愛媛_ave_'+i_new_ehime+'_'+j_new+'.tif'
                    bilat_ehime = base_new + q + r +  condition_ehime + 'MRIT2画像_愛媛_bilat_'+i_new_ehime+'_'+j_new+'.tif'
                    gaus_ehime = base_new + q + r +  condition_ehime + 'MRIT2画像_愛媛_gaussian_'+i_new_ehime+'_'+j_new+'.tif'
                    median_ehime = base_new + q + r +  condition_ehime + 'MRIT2画像_愛媛_median_'+i_new_ehime+'_'+j_new+'.tif'
                    noise_ehime = base_new + q + r +  condition_ehime + 'MRIT2画像_愛媛_noise_'+i_new_ehime+'_'+j_new+'.tif'
                    xshear_ehime = base_new + q + r +  condition_ehime + 'MRIT2画像_愛媛_xshear_'+i_new_ehime+'_'+j_new+'.tif'
                    yshear_ehime = base_new + q + r +  condition_ehime + 'MRIT2画像_愛媛_yshear_'+i_new_ehime+'_'+j_new+'.tif'
                    shift_ehime = base_new + q + r + condition_ehime + 'MRIT2画像_愛媛_shift_'+i_new_ehime+'_'+j_new+'.tif'
                    round_ehime = base_new + q + r + condition_ehime + 'MRIT2画像_愛媛_round_' + i_new_ehime + '_' + j_new + '.tif'
                    
                    # imwrite(bright_ehime, img_bright)
                    # imwrite(dark_ehime, img_dark)
                    imwrite(bilat_ehime, img_bilat)
                    # imwrite(gaus_ehime, img_gaus)
                    # imwrite(median_ehime, img_median)
                    # imwrite(noise_ehime, img_noise)
                    # imwrite(xshear_ehime, img_xshear)
                    # imwrite(yshear_ehime, img_yshear)
                    # imwrite(shift_ehime, img_shift)
                    # imwrite(ave_ehime, img_ave)
                    # imwrite(round_ehime, img_round)
            
for i in range(len(lenshizuoka)):
    x = shizuokalist[i]
    x1 = x[0].split('_')
    ye = int(x1[0])-132
    for count in range(132):
        im = str(count+2)
        fd = 'A' + im
        fd_new = ws_shizuoka[fd].value
        if fd_new == ye:
            t = 'S' + im
            type = str(ws_shizuoka[t].value)
            break
    a = 'A' + im
    b = 'B' + im
    a_shizuoka = str(ws_shizuoka[a].value)
    b_shizuoka = str(ws_shizuoka[b].value)
    i_new_shizuoka = a_shizuoka.zfill(3)

    for j in range(5):
        j_new = str(j+1)
            
        if type == "良性":
            condition_shizuoka = "good/"
        else:
            condition_shizuoka = "bad/"

        bright_shizuoka = base_old + bright   + 'MRIT2画像_静岡_bright_'+i_new_shizuoka+'_'+j_new+'.tif'
        dark_shizuoka = base_old + dark   + 'MRIT2画像_静岡_dark_'+i_new_shizuoka+'_'+j_new+'.tif'
        ave_shizuoka = base_old + ave +   'MRIT2画像_静岡_ave_'+i_new_shizuoka+'_'+j_new+'.tif'
        bilat_shizuoka = base_old + bilat   + 'MRIT2画像_静岡_bilat_'+i_new_shizuoka+'_'+j_new+'.tif'
        gaus_shizuoka = base_old + gaus +   'MRIT2画像_静岡_gaussian_'+i_new_shizuoka+'_'+j_new+'.tif'
        median_shizuoka = base_old + median   + 'MRIT2画像_静岡_median_'+i_new_shizuoka+'_'+j_new+'.tif'
        noise_shizuoka = base_old + noise +  'MRIT2画像_静岡_noise_'+i_new_shizuoka+'_'+j_new+'.tif'
        xshear_shizuoka = base_old + xshear   + 'MRIT2画像_静岡_xshear_'+i_new_shizuoka+'_'+j_new+'.tif'
        yshear_shizuoka = base_old + y_shear   + 'MRIT2画像_静岡_yshear_'+i_new_shizuoka+'_'+j_new+'.tif'
        shift_shizuoka = base_old + shift +   'MRIT2画像_静岡_shift_'+i_new_shizuoka+'_'+j_new+'.tif'
        round_shizuoka = base_old + round +   'MRIT2画像_静岡_round_' + i_new_shizuoka + '_' + j_new + '.tif'
        is_file_shizuoka = os.path.isfile(bright_shizuoka)

        if is_file_shizuoka:
            n = lenshizuoka[i]
            # print(n)
            if n == 1:
                if j == 0 or j == 1 or j == 2 or j == 3 or j == 4:
                    j_flag = 1
            if n == 2:
                if j == 0 or j == 2 or j == 3:
                    j_flag = 1
                if j == 1 or j == 4:
                    j_flag = 2
            if n == 3:
                if j == 0 or j == 3:
                    j_flag = 1
                if j == 1 or j == 4:
                    j_flag = 2
                if j == 2:
                    j_flag = j + 1
            if n == 4:
                if j == 0 or j == 4:
                    j_flag = 1
                else:
                    j_flag = j + 1
            if n == 5:
                j_flag = j + 1

            if j_flag == 1:
                w = 'U'+im
                x = 'V'+im
                y = 'W'+im
                z = 'X'+im
            if j_flag == 2:
                w = 'Y'+im
                x = 'Z'+im
                y = 'AA'+im
                z = 'AB'+im
            if j_flag == 3:
                w = 'AC'+im
                x = 'AD'+im
                y = 'AE'+im
                z = 'AF'+im
            if j_flag == 4:
                w = 'AG'+im
                x = 'AH'+im
                y = 'AI'+im
                z = 'AJ'+im
            if j_flag == 5:
                w = 'AK'+im
                x = 'AL'+im
                y = 'AM'+im
                z = 'AN'+im
            
            w = ws_shizuoka[w].value
            x = ws_shizuoka[x].value
            y = ws_shizuoka[y].value
            z = ws_shizuoka[z].value
            img_bright = io.imread(bright_shizuoka)
            img_dark = io.imread(dark_shizuoka)
            img_ave = io.imread(ave_shizuoka)
            img_bilat = io.imread(bilat_shizuoka)
            img_gaus = io.imread(gaus_shizuoka)
            img_median = io.imread(median_shizuoka)
            img_noise = io.imread(noise_shizuoka)
            img_xshear = io.imread(xshear_shizuoka)
            img_yshear = io.imread(yshear_shizuoka)
            img_shift = io.imread(shift_shizuoka)
            img_round = io.imread(round_shizuoka)

            # img_bright = img_bright[x:x+z,w:w+y]
            # img_dark = img_dark[x:x+z,w:w+y]
            # img_ave = img_ave[x:x+z,w:w+y]
            # img_bilat = img_bilat[x:x+z,w:w+y]
            # img_gaus = img_gaus[x:x+z,w:w+y]
            # img_median = img_median[x:x+z,w:w+y]
            # img_noise = img_noise[x:x+z,w:w+y]
            # img_xshear = img_xshear[x:x+z,w:w+y]
            # img_yshear = img_yshear[x:x+z,w:w+y]
            # img_shift = img_shift[x:x+z,w:w+y]
            # img_round = img_round[x:x+z,w:w+y]
            for q in trainlist:
                for r in dir_new:
                    bright_shizuoka = base_new + q + r + condition_shizuoka + 'MRIT2画像_静岡_bright_'+i_new_shizuoka+'_'+j_new+'.tif'
                    print(bright_shizuoka)
                    dark_shizuoka = base_new + q + r + condition_shizuoka + 'MRIT2画像_静岡_dark_'+i_new_shizuoka+'_'+j_new+'.tif'
                    ave_shizuoka = base_new + q + r + condition_shizuoka + 'MRIT2画像_静岡_ave_'+i_new_shizuoka+'_'+j_new+'.tif'
                    bilat_shizuoka = base_new + q + r  + condition_shizuoka + 'MRIT2画像_静岡_bilat_'+i_new_shizuoka+'_'+j_new+'.tif'
                    gaus_shizuoka = base_new + q + r  + condition_shizuoka + 'MRIT2画像_静岡_gaussian_'+i_new_shizuoka+'_'+j_new+'.tif'
                    median_shizuoka = base_new + q + r  + condition_shizuoka + 'MRIT2画像_静岡_median_'+i_new_shizuoka+'_'+j_new+'.tif'
                    noise_shizuoka = base_new + q + r  + condition_shizuoka + 'MRIT2画像_静岡_noise_'+i_new_shizuoka+'_'+j_new+'.tif'
                    xshear_shizuoka = base_new + q + r  + condition_shizuoka + 'MRIT2画像_静岡_xshear_'+i_new_shizuoka+'_'+j_new+'.tif'
                    yshear_shizuoka = base_new + q + r + condition_shizuoka + 'MRIT2画像_静岡_yshear_'+i_new_shizuoka+'_'+j_new+'.tif'
                    shift_shizuoka = base_new + q + r  + condition_shizuoka + 'MRIT2画像_静岡_shift_'+i_new_shizuoka+'_'+j_new+'.tif'
                    round_shizuoka = base_new + q + r + condition_shizuoka + 'MRIT2画像_静岡_round_' + i_new_shizuoka + '_' + j_new + '.tif'

                    # imwrite(bright_shizuoka, img_bright)
                    # imwrite(dark_shizuoka, img_dark)
                    # imwrite(ave_shizuoka, img_ave)
                    imwrite(bilat_shizuoka, img_bilat)
                    # imwrite(gaus_shizuoka, img_gaus)
                    # imwrite(median_shizuoka, img_median)
                    # imwrite(noise_shizuoka, img_noise)
                    # imwrite(xshear_shizuoka, img_xshear)
                    # imwrite(yshear_shizuoka, img_yshear)
                    # imwrite(shift_shizuoka, img_shift)
                    # imwrite(round_shizuoka, img_round) 